#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <iostream>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/wait.h>
#include <fstream>
#include <fcntl.h>

#include <bits/stdc++.h>

#include <termios.h>
#include <stdio.h>
#include <ctype.h>

#include "../request.h"
#include "../train.h"

// server.h
#ifndef SERVER_H
#define SERVER_H

#define MAX_SIZE 1024
#define MAX_BACKLOG 10

using namespace std;

static struct termios old;
static struct termios _new;


/* Initialize _new terminal i/o settings */
void initTermios(int echo) 
{
  tcgetattr(0, &old); /* grab old terminal i/o settings */
  _new = old; /* make _new settings same as old settings */
  _new.c_lflag &= ~ICANON; /* disable buffered i/o */
  _new.c_lflag &= echo ? ECHO : ~ECHO; /* set echo mode */
  tcsetattr(0, TCSANOW, &_new); /* use these _new terminal i/o settings now */
}

/* Restore old terminal i/o settings */
void resetTermios(void) 
{
  tcsetattr(0, TCSANOW, &old);
}

/* Read 1 character - echo defines echo mode */
char getch_(int echo) 
{
  char ch;
  initTermios(echo);
  ch = getchar();
  resetTermios();
  return ch;
}

/* Read 1 character without echo */
char getch(void) 
{
  return getch_(0);
}

/* Read 1 character with echo */
char getche(void) 
{
  return getch_(1);
}



struct record
{
  vector<Request> req;
  int file_descrip;

  //record(vector<Request> r,int fd) : req(r) , file_descrip(fd) {}

};
/*
bool pair_comparator(const record& struct1,const record& struct2)
{

      time_t t1,t2;

      t1=struct1.req.timestamp;
      t2=struct2.req.timestamp;

      return difftime(t1,t2)<0;   // !!! //
}

bool numberCompare(const Request& first, const Request& second)
{  
  	return ( first.num_of_berths > second.num_of_berths);
}
*/

class Server
{

private:
  vector<int> recent_2_handle; // a vector af all the recent incoming simultaneous connections, that need to be handled
  //Book_Details response_2_client;
   Request client_array[MAX_BACKLOG]; 
   // client_socket[i] file descriptor --- > corresponds to the <--- client_array[i] request object

    int pid,sd;

  //  Book_Details response_2_client;//[MAX_SIZE];
   // Request buffer[MAX_SIZE];
    int buffer_list_counter,book_detail_list_counter;

    vector<Train> train_list;
   // vector<record> req_list__vector; // a vector of many (lists of requests)

    fd_set readfds,writefds,errorfds;
    int listen_socket,new_socket,max_sockfd,client_socket[MAX_BACKLOG];
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr; // server address and client address respectively

void setnonblocking(int sock)
{
  int opts;

  opts = fcntl(sock,F_GETFL);
  if (opts < 0) {
    perror("fcntl(F_GETFL)");
    exit(EXIT_FAILURE);
  }
  opts = (opts | O_NONBLOCK);
  if (fcntl(sock,F_SETFL,opts) < 0) 
  {
    perror("fcntl(F_SETFL)");
    exit(EXIT_FAILURE);
  }
  return;
}

public:
  Server(int portno, vector<Train> train_list)
  {
    buffer_list_counter=0;
    book_detail_list_counter=0;

    this->train_list=train_list;
    if((listen_socket = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0)) <0) error("Error in opening TCP Server Socket !");

    /* So that we can re-bind to it without TIME_WAIT problems */
    int reuse_addr=1;
    setsockopt(listen_socket, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(reuse_addr));
    setnonblocking(listen_socket);

     bzero((char *) &serv_addr, sizeof(serv_addr));

     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);

     if ((bind(listen_socket,(struct sockaddr *)&serv_addr, sizeof(serv_addr)))<0) error("Error in binding the TCP Socket to the address !");
     
     clilen = sizeof(cli_addr);

     //initialise all client_socket[] to 0 so not checked
    for (int i = 0; i < MAX_BACKLOG; i++) client_socket[i] = -1;
    
     this->startListening();

  }

  ~Server()
  {
    //close(listen_socket);
  }
private:
    void error(const char* error_mssg)
    {
      perror(error_mssg);
      exit(1);
    }

void startListening()
{
    
    listen(listen_socket,MAX_BACKLOG);

    //cout<< "My IP : "<< this->getIP() << " !" << endl;

    while(1)
    {

      int status;
      cout << "\n\n\n ---------------------------------------------------------------------------------------- \n" ;
      cout<<"\n TCP Server running...\n\n";
      
      cout << "\nEnter 1 to show the Reservation Details of all the trains...\n";
      cout << "Enter Q to quit...\n";


      //clear the socket set
        FD_ZERO(&readfds);
        FD_ZERO(&writefds);
        FD_ZERO(&errorfds);
  
        //add master socket to set
        FD_SET(listen_socket, &readfds);   

        // add stdin to the read set
        FD_SET(0,&readfds);

        max_sockfd = listen_socket;
         
        //add child sockets to set
        for (int i = 0 ; i < MAX_BACKLOG ; i++) 
        {
            //socket descriptor
            int sd = client_socket[i];
             
            //if valid socket descriptor then add to read list
            if(sd > 0)
                FD_SET( sd , &readfds);
             
            //highest file descriptor number, need it for the select function
            if(sd > max_sockfd)
                max_sockfd = sd;
        }
          
          struct timeval tm;
          tm.tv_sec = 10;
          tm.tv_usec = 0;
        //wait for an activity on one of the sockets , timeout is NULL , so wait indefinitely
        int activity = select( max_sockfd + 1 , &readfds , &writefds , &errorfds , &tm);
    
        if ((activity < 0) && (errno!=EINTR)) error("select error");
        //else cout << "Found activity of count : " << activity <<" on server " << endl;

        // if something happened on STDIN, process the input
        if(FD_ISSET(0,&readfds))
        {
          if((pid=fork())==0)
          {
          //  cout << "Forking " << endl;
         // system("clear");
          fflush(0);
          waitForInput();
          exit(0);
          }

          if(waitpid(pid,&status,0)==pid)
             if(WEXITSTATUS(status)==1)
                 exit(0);
        }
          
        //If something happened on the master socket , then its an incoming connection
        if (FD_ISSET(listen_socket, &readfds)) 
        {
            if ((new_socket = accept(listen_socket, (struct sockaddr *)&cli_addr, (socklen_t*)&clilen))<0) error("Error on Accepting TCP Connection Request !");
            setnonblocking(new_socket);
            //inform user of socket number - used in send and receive commands
             char cli_ip[INET_ADDRSTRLEN];
            if(inet_ntop(AF_INET,&(cli_addr.sin_addr),cli_ip,INET_ADDRSTRLEN)==NULL) error("Error in determining client IP Address !");
            
            cout<<"@ port : " << ntohs(cli_addr.sin_port) << " TCP Connection made with the client " << cli_ip << " !\n\n";
          

           // char message[20]="Welcome !\n";
            //send new connection greeting message
           // if( send(new_socket, message, strlen(message), 0) != strlen(message) ) error("Error in send !");
              
          //  puts("Welcome message sent successfully");
              
            //add new socket to array of sockets
            for (int i = 0; i < MAX_BACKLOG; i++) 
            {
                //if position is empty
                if( client_socket[i] == -1 )
                {
                    client_socket[i] = new_socket;
                    printf("Adding the socket %d to list of sockets at index %d\n" ,client_socket[i], i);
                     
                    break;
                }
            }
        }
          int simultaneous_count=0;

        for (int i = 0; i < MAX_BACKLOG; i++) 
        {

            if(client_socket[i] <=0)
              continue;

             // cout << "Reached 6! for client_socket [" << i << "]" << endl;
            recent_2_handle.clear();

            if (FD_ISSET( client_socket[i] , &readfds))
            {

                  int number_of_bytes = read(client_socket[i], (char*)&client_array[i], sizeof(client_array[i]));

                  if(number_of_bytes<0) error("Error in receiving Request object from booking agent !\n\n");
                  else if(number_of_bytes==0)
                 {
                  cout << "Connection closed from a booking agent ! Resetting its socket_slot for later reuse...\n";
                   client_socket[i]=-1;
                   continue;
                  }
                  else 
                    {
                      getpeername( client_socket[i] , (struct sockaddr*)&cli_addr , (socklen_t*)&clilen);   
                      cout<<" Received Request object from booking agent  : " << inet_ntoa(cli_addr.sin_addr) << " and port : " << ntohs(cli_addr.sin_port) << "\n\n";
                      recent_2_handle.push_back(i);
                      simultaneous_count++;
                    }
            }
        }

      ///////  @ any point, simultaneous_count maintains the count of the recent_2_handle vector 

        while(simultaneous_count>0)
        {
          cout << " NOW simultaneous_count = " << simultaneous_count << endl;

        int select_pos=-1;

        for(int indx = 0 ; indx < simultaneous_count ; indx ++ )
        {
          int i = recent_2_handle[indx];

            if(select_pos==-1)
            {
              select_pos=i;
              continue;
            }
            else
            {

              if(difftime(client_array[i].timestamp,client_array[select_pos].timestamp)<0)
              {
                select_pos=i;
                continue;
              }
              else if(difftime(client_array[i].timestamp,client_array[select_pos].timestamp)==0)
              {
                // tie on basis of timestamp

                cout << "Tie on timestamp : t1 : " << client_array[i].timestamp << " t2 : " << client_array[select_pos].timestamp << endl;
                // use tie - breaker
                select_pos = policySelect(i,select_pos);
              }
              else ; // do nothing // the select_pos will remain the same !

            }
        }
          

        // handle the client with selected index
        cout << " Handling the selected client @ index : " << select_pos << " socket fd : " << client_socket[select_pos] << endl;
        handleClient(select_pos);
        simultaneous_count--;

        recent_2_handle.erase(remove(recent_2_handle.begin(), recent_2_handle.end(), select_pos), recent_2_handle.end());

      }// simultaneous while ends

      } // while(1) ends...
} // function startListenng() ends...


void printReservationDetails()
{
  cout << "\n\n TRAIN NAME      TRAIN NO.          AC Seats :  Total [ Booked / Available ]          Sleeper Seats : Total [ Booked / Available ] \n\n";
  for( vector<Train>::iterator it=train_list.begin() ; it!= train_list.end() ; it++)
  {
    int train_no=it->getID();
    char* name = it->getName();

    int bookedAC = it->getNoofAvailableSeats(true,true,false) + it->getNoofAvailableSeats(false,true,false);
    int availAC = it->getNoofAvailableSeats(true,true,true) + it->getNoofAvailableSeats(false,true,true);
    int totalAC = bookedAC + availAC;

    int availSlpr = it->getNoofAvailableSeats(true,false,true) + it->getNoofAvailableSeats(false,false,true);
    int bookedSlpr = it->getNoofAvailableSeats(true,false,false) + it->getNoofAvailableSeats(false,false,false);
    int totalSlpr = bookedSlpr + availSlpr;

    cout << " " << name << "     " << train_no << "                      " << totalAC << "[ " << bookedAC << " / " << availAC << " ]                          " << totalSlpr<< " [ " << bookedSlpr<< " / " << availSlpr<<" ] \n\n";
  
  }
}

/*
int policySelect(int indx1, int indx2)
{
  // analyze the selection by iterating the vector client_array 
  // so as to resolve between the indices indx1 and indx2

  // and return the winner index 
  return indx2;
}


void handleClient(int index)
{
  // handle the client using client_socket[index] (as file descriptor) & client_array[index] (as Request object)

  // and save the result / response  to the response_2_client (Book_Details object)

   response_2_client.book_ID=client_array[index].book_ID;
   response_2_client.num_of_berths=client_array[index].num_of_berths;
   response_2_client.train_no=client_array[index].train_no;

   // cout << response_2_client.book_ID << endl;
   // cout << response_2_client.num_of_berths << endl;
   // cout << response_2_client.train_no << endl;

    for(int i=0;i<client_array[index].num_of_berths;i++)
    {
      strcpy(response_2_client.coaches[i],"A1");

      int n=i;
      while(train_list[0].coaches[0]->berths[n].alloc == true)
        n++;

      train_list[0].coaches[0]->berths[n].alloc = true;
      response_2_client.seat_no[i]= train_list[0].coaches[0]->berths[n].seat_no;
      response_2_client.position[i]= train_list[0].coaches[0]->berths[n].position;

      // cout << response_2_client.coaches[i] << endl;
       // cout << response_2_client.seat_no[i] << endl;
        // cout << response_2_client.position[i] << endl;
    }

          int valwrite;
          //handleClient(i);//,inp_req_list);
// sending index i  means handle the client_socket[i] file_descriptor and client_array[i] request object
          
          if ((valwrite = write( client_socket[index] ,(char*) &response_2_client, sizeof(response_2_client))) <= 0)
                error("Error in sending response_2_client !\n");
          else{
            getpeername( client_socket[index] , (struct sockaddr*)&cli_addr , (socklen_t*)&clilen);   
            cout << "Sent the response to the Client @ IP : " << inet_ntoa(cli_addr.sin_addr) << " and port : " << ntohs(cli_addr.sin_port) << "\n\n";
          }

}
*/


int policySelect(int indx1, int indx2)
{
  // analyze the selection by iterating the array client_array 
  // so as to resolve between the indices indx1 and indx2

  // and return the winner index 
  int seniors_1 = 0, seniors_2 = 0;

  if (client_array[indx1].num_of_berths > client_array[indx2].num_of_berths)
  return indx1;
  else if (client_array[indx1].num_of_berths < client_array[indx2].num_of_berths)
    return indx2;
  else
  {
  int n = client_array[indx1].num_of_berths;
  for (int i=0 ; i<n ; i++)
  {
    if(client_array[indx1].pass_ages[i] >= 60)
      seniors_1++;
    if(client_array[indx2].pass_ages[i] >= 60)
      seniors_2++;
  }
  if (seniors_1 >= seniors_2)
    return indx1;
  else
    return indx2;
  }
}


void handleClient(int index)
{
  // handle the client using client_socket[index] (as file descriptor) & client_array[index] (as Request object)

  // and save the result / response  to the response_2_client (Book_Details object)

  Book_Details response_2_client;

  int train_no = client_array[index].train_no;  
  int coach_type = client_array[index].coach_type;
  int num_of_berths = client_array[index].num_of_berths;
  int left = num_of_berths;
  bool var;
  int x = 0;
  int flag_train = 0;
  if(coach_type == Coach :: AC)
  var = true;
  else
  var = false;


        response_2_client.book_ID = client_array[index].book_ID; 
        response_2_client.num_of_berths = num_of_berths; 
        response_2_client.train_no = train_no; 

  //cout << "Coach Type = " << coach_type << endl;

  for(vector<Train>::iterator it1 = train_list.begin(); it1 != train_list.end(); it1++)
  {
  if(it1->ID == train_no)
  {
    //cout << "Train No. " <<train_no << " Coach : " << ((it1->coaches)[0])->name<<endl;
    flag_train = 1;
    if( (it1->getNoofAvailableSeats(true,var) + it1->getNoofAvailableSeats(false,var)) < num_of_berths )
      	{
		cout << "No Seats Available!\n";
	}
    else
    {
        response_2_client.book_ID = client_array[index].book_ID; 
        response_2_client.num_of_berths = num_of_berths; 
        response_2_client.train_no = train_no; 

        int prefer[6];
        int flag = 0;
       
        for(int k=0;k<=5;k++) prefer[k] = 0;

	if(client_array[index].berth_preferences[0]==-1)
	{
		prefer[1]++;
	}
	else
	{
		for(int k=0; k<num_of_berths; k++)
		{
		  prefer[client_array[index].berth_preferences[k]]++;
		  cout << "prefer["<<client_array[index].berth_preferences[k]<<"]="<<prefer[client_array[index].berth_preferences[k]]<<endl;
		}
	}

       // cout << "Hello " << endl;
        
      
        for(vector<Coach*>::iterator it2 = (it1->coaches).begin(); it2 !=  (it1->coaches).end(); it2++)
        {
         // cout << " trying coach = " << (*it2)->type  << endl;
         //  cout << " coach type : " << coach_type << endl;


          if((*it2)->type == coach_type)
          {           
           // cout << "coach_type = " <<(*it2)->type << endl;

          //  cout << (*it2)->getSU() << " --- " << prefer[1] << endl;
          //  cout << (*it2)->getSL() << " --- " << prefer[2] << endl;
          //  cout << (*it2)->getUB() << " --- " << prefer[3] << endl;
          //  cout << (*it2)->getMB() << " --- " << prefer[4] << endl;
          //  cout << (*it2)->getLB() << " --- " << prefer[5] << endl;


            if((*it2)->getSU()>=prefer[1] && (*it2)->getSL()>=prefer[2] && (*it2)->getUB()>=prefer[3] && (*it2)->getMB()>=prefer[4] && (*it2)->getLB()>=prefer[5])
            {
              //cout << " inside 2nd if " << endl;
              flag = 1;
	      //cout << "Yes\n";
              for(vector<Berth>::iterator it3 = ((*it2)->berths).begin(); it3 !=  ((*it2)->berths).end(); it3++)
              {
                //if(train_no == 12301)cout << " inside 2nd for " << endl;
		
                for(int h = 1; h<=5; h++)
                {   
                  //if(train_no == 12301)cout << " inside 3rd for " << endl;
                  if(prefer[h])
                  {
                    //if(train_no == 12301)cout << " inside 3rd if " << endl;
		    //if(train_no == 12301){cout << it3->alloc<<endl;}
                    if(it3->alloc == false && it3->position == h)
                    {
                    //cout << " inside 4th if " << endl;

                      prefer[h]--;
                      it3->alloc = true;
                      //cout << " Coach Name : " << (*it2)-> name << endl;

                      strcpy(response_2_client.coaches[x],(*it2)-> name);

                      //cout << " Coach Name Allotted : " << response_2_client.coaches[x] << endl;

                      response_2_client.position[x] = it3-> position;
                      response_2_client.seat_no[x++] = it3-> seat_no;
                    }   
                  }
                }                                                       
              } 
            }  
          }
        }
        if(flag == 1)
        {
          	break;
        }
        else
        {
          int max = 0, select;

          int done[(it1->coaches).size()];

	  //cout << "Number of Coaches = " <<(it1->coaches).size() << endl;;

	  for(int y=0; y< (it1->coaches).size() ; y++)
          	{done[y]=0;}

          while(left!=0)
          {      
	    //cout << "left = " << left << endl;
            max = 0;int sum;
            for(int a = 0 ; a <  (it1->coaches).size(); a++)
            {
		sum = 0;
		if((it1->coaches)[a]->type == coach_type)
		{               
		       //sum = (it1->coaches)[a]->getSU()+(it1->coaches)[a]->getSL()+(it1->coaches)[a]->getUB()+(it1->coaches)[a]->getMB()+(it1->coaches)[a]->getLB();
		       //cout << "coach_type = " << coach_type << endl;
		       if(prefer[1] != 0)
				sum = sum + (it1->coaches)[a]->getSU();
		       if(prefer[2] != 0)
				sum = sum + (it1->coaches)[a]->getSL();
		       if(prefer[3] != 0)
				sum = sum + (it1->coaches)[a]->getUB();
		       if(prefer[4] != 0)
				sum = sum + (it1->coaches)[a]->getMB();
		       if(prefer[5] != 0)
				sum = sum + (it1->coaches)[a]->getLB();
		       if(sum>max && done[a] == 0) 
		     		{max = sum;select =a;}        
		}
		/*cout << a <<".max = " << max << endl;
		cout << a <<".Sum = " << sum << endl;
	    	cout << a <<".Select = " << select << endl;
		cout << "Status = " <<((it1->coaches)[select])->berths[0].alloc << endl;*/
            }
	    //cout <<"max = " << max << endl;
	    //cout << "Sum = " << sum << endl;
	    //cout << "Select = " << select << endl;
            if(max!=0)
            {
		done[select] = 1;
		
		for(vector<Berth>::iterator it3 = ((it1->coaches)[select]->berths).begin(); it3 !=  ((it1->coaches)[select]->berths).end(); it3++)
		{		    
		    for(int h = 1; h<=5; h++)
		    {   
		      if(prefer[h])
		      {
		        if(it3->alloc == false && it3->position == h)
		        {
			  //cout << "booked seat no = " << it3-> seat_no << " and position =" << it3-> position << endl;
		    	  prefer[h]--;
		    	  left--;
		          it3->alloc = true;
		          strcpy(response_2_client.coaches[x],((it1->coaches)[select])->name);
		          response_2_client.position[x] = it3-> position;
		          response_2_client.seat_no[x++] = it3-> seat_no;
		        }   
		      }
		    }                                                       
		}
	    }
            else
         	break;            
          }
          if(left != 0)
          {
	    //cout << "LEFT = " << left << endl;
            for(vector<Coach*>::iterator it2 = (it1->coaches).begin(); it2 !=  (it1->coaches).end(); it2++)
            {
              if((*it2)->type == coach_type)
              {                             
                  for(vector<Berth>::iterator it3 = ((*it2)->berths).begin(); it3 !=  ((*it2)->berths).end(); it3++)
                  {                  
                    if(it3->alloc == false && left != 0)
                    {
			    //cout << "booked seat no = " << it3-> seat_no << " and position =" << it3-> position << endl;
                            it3->alloc = true;                      
			    left--;
			    strcpy(response_2_client.coaches[x],(*it2)-> name);
			    response_2_client.position[x] = it3-> position;
			    response_2_client.seat_no[x++] = it3-> seat_no;
                    }                                                               
                  }                                    
              }
            }
           }
        }
    }
  }
  }

  if(flag_train == 0)
  	cout<<"No such Train with Given ID available!\n";
  else
  {
    int valwrite;

    valwrite = write(client_socket[index], (char*)&response_2_client, sizeof(response_2_client));

    if( valwrite <=0 )
      error("Error in sending response_2_client !\n");
          else
          {
            getpeername( client_socket[index] , (struct sockaddr*)&cli_addr , (socklen_t*)&clilen);   
            cout << "Sent the response to the Client @ IP : " << inet_ntoa(cli_addr.sin_addr) << " and port : " << ntohs(cli_addr.sin_port) << "\n\n";
          }
  }
  
}


void waitForInput()
{
        char choice=getch();
          switch (choice)
          {
            case '1': printReservationDetails();
                      break;
            case 'q': /* terminate the server */
            case 'Q':
                      cout << "Terminating the server !\n\n";
                      exit(1);
                      break;
            default: /* bad input */
                      cout << "ERROR: unknown command\n" ;        
          } 
} 

public:
    char* getIP()
    {
      char ip[INET_ADDRSTRLEN];
      if(inet_ntop(AF_INET,&(serv_addr.sin_addr),ip,INET_ADDRSTRLEN)==NULL) error("Error in returning IP Address !");
      return strdup(ip);
    }
};

#endif
