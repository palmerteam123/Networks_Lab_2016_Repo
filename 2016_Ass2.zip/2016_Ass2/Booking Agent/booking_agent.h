#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <iostream>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/wait.h>
#include <fstream>
#include <stdio.h>
#include <termios.h>
#include <ctype.h>
#include <sstream>
#include "../request.h"
#include "../train.h"

// booking_agent.h
#ifndef BOOKING_AGENT_H
#define BOOKING_AGENT_H

#define MAX_SIZE 1024

using namespace std;


static struct termios old;
static struct termios _new;

inline bool fileExists (const string& name) {
    ifstream f(name.c_str());
    if (f.good()) {
        f.close();
        return true;
    } else {
        f.close();
        return false;
    }   
}


vector<string> split(string str, char delimiter) {
  vector<string> internal;
  stringstream ss(str); // Turn the string into a stream.
  string tok;
  
  while(getline(ss, tok, delimiter)) {
    internal.push_back(tok);
  }
  
  return internal;
}

/* Initialize _new terminal i/o settings */
void initTermios(int echo) 
{
  tcgetattr(0, &old); /* grab old terminal i/o settings */
  _new = old; /* make _new settings same as old settings */
  _new.c_lflag &= ~ICANON; /* disable buffered i/o */
  _new.c_lflag &= echo ? ECHO : ~ECHO; /* set echo mode */
  tcsetattr(0, TCSANOW, &_new); /* use these _new terminal i/o settings now */
}

/* Restore old terminal i/o settings */


void resetTermios(void) 
{
  tcsetattr(0, TCSANOW, &old);
}

/* Read 1 character - echo defines echo mode */
char getch_(int echo) 
{
  char ch;
  initTermios(echo);
  ch = getchar();
  resetTermios();
  return ch;
}

/* Read 1 character without echo */
char getch(void) 
{
  return getch_(0);
}

/* Read 1 character with echo */
char getche(void) 
{
  return getch_(1);
}

string itoa(int a)
{
    string ss="";   //create empty string
    while(a)
    {
        int x=a%10;
        a/=10;
        char i='0';
        i=i+x;
        ss=i+ss;      //append new character at the front of the string!
    }
    return ss;
}


class Booking_Agent
{
private:
  Request req_list[20];
  Book_Details* book_detail_list[20];
  int req_list_counter,book_detail_list_counter;

  int sockfd,portno;
  char serverIP[20];
  struct sockaddr_in serv_addr;

  void error(const char* error_mssg)
    {
      perror(error_mssg);
      exit(1);
    }
public:
  Booking_Agent(char serverIP[20],int portno)
  {
    req_list_counter=0;
    book_detail_list_counter=0;

    strcpy(this->serverIP,serverIP);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if(sockfd<0)
      error("Error in opening Booking_Agent Socket");

    this->portno=portno;

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portno);

    /* either this
    struct hostent* server;
    server = gethostbyname(serverIP); // if serverIP is a DNS name // need to insert a new mapping in /etc/hosts file
       if (server == NULL) {
          fprintf(stderr,"ERROR, no such host\n");
          exit(0);
      }
      bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
      */


      // OR this 
  //  if serverIP is an IP address in dot notation
    inet_pton(AF_INET, serverIP, &(serv_addr.sin_addr));

  }
private:
  void parseInputCSV(const char* filename)
  {
    string line[100];
    int i=0;

   ifstream myfile( filename);
  if (myfile)  
    {
    while (getline( myfile, line[i] )) 
      i++;

    myfile.close();
    }
    
    int lineCount=i;

    for(i=0;i<lineCount;i++)
    {

      vector<string> tokens = split(line[i],',');

      int _id_=stoi(tokens[0],NULL,10);
      int _train_no_=stoi(tokens[1],NULL,10);
      int _coach_type_;
      if(tokens[2]=="AC")
        _coach_type_= Coach::AC;
      else if(tokens[2]=="Sleeper")
        _coach_type_= Coach::Sleeper;

      int _num_of_berths_=stoi(tokens[3],NULL);

      int prefer[_num_of_berths_+1];
      if(tokens[4]=="NA")
        prefer[0]=-1;
      else
      {
        vector<string> tok = split(tokens[4],'-');

        int n = _num_of_berths_-1;
        prefer[_num_of_berths_] = -1;
        while(n >= 0)
        {
          if(tok[n] == "SU")
            prefer[n]=Berth::SU;
          else if(tok[n] == "SL")
            prefer[n]=Berth::SL;
          else if(tok[n] == "UB")
            prefer[n]=Berth::UB;
          else if(tok[n] == "MB")
            prefer[n]=Berth::MB;
          else if(tok[n] == "LB")
            prefer[n]=Berth::LB;
          else error("Erroneous parsing here !");
          n--;
        }
      }

        int ages[_num_of_berths_];
      
        vector<string> tok1 = split(tokens[5],'-');

        int n = _num_of_berths_- 1;
        
        while(n >= 0)
        {
          
          ages[n]=stoi(tok1[n],NULL);
          n--;
        }
      int indx=req_list_counter++;
      time_t _timestamp_ = time(0); 
      req_list[indx].book_ID=_id_;
      req_list[indx].train_no=_train_no_;
      req_list[indx].coach_type = _coach_type_;
      req_list[indx].num_of_berths=_num_of_berths_;
      req_list[indx].timestamp = time(0);

      for(int i=0;i<=_num_of_berths_;i++)
      {
        if(prefer[0]!=-1)
          req_list[indx].berth_preferences[i]=prefer[i];
        req_list[indx].pass_ages[i]=ages[i];
      }

    if(prefer[0]==-1)
      req_list[indx].berth_preferences[0]=-1;
    }

    return;
  }

  void dealWithServer()
  {
   // cout<<420;
    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) error("Error in connecting to TCP Server !");
    else cout<<" Connected to the TCP Server "<< serverIP<<endl;
   // system("clear");
  //  cout << req_list_counter << endl;
    for(int i=0; i<req_list_counter ; i++)
    {
        int write_count=write(sockfd,(char*)&req_list[i],sizeof(req_list[i]));

        if(write_count<=0) error("Error in sending object to TCP Server !\n\n");
        else
          cout << "sent the Request [" << i+1 << "] to the Booking server \n";

        book_detail_list[i] = new Book_Details();

         int read_count=read(sockfd,(char*)book_detail_list[i],sizeof(Book_Details));

        if(read_count<=0) error("Error in receiving response from TCP Server !\n");
        else cout << "\nreceived Server Response for Request [" << i+1 << "]\n"<< endl;


        sleep(1); // sleep for 1 second
    }

    close(sockfd);
  }

   string pos_repr(int* pos_arr,int n)
  {
    string str="";
    int i=0;

    switch(pos_arr[i])
    {
      case Berth::UB:
      str=str+"UB";
      break;
      case Berth::LB:
      str=str+"LB";
      break;
      case Berth::MB:
      str=str+"MB";
      break;
      case Berth::SL:
      str=str+"SL";
      break;
      case Berth::SU:
      str=str+"SU";
      break;
    }

    for(i=1;i<n;i++)
    {
      switch(pos_arr[i])
    {
      case Berth::UB:
      str=str+"-UB";
      break;
      case Berth::LB:
      str=str+"-LB";
      break;
      case Berth::MB:
      str=str+"-MB";
      break;
      case Berth::SL:
      str=str+"-SL";
      break;
      case Berth::SU:
      str=str+"-SU";
      break;
    }

    }
    return str;
  }

  string coach_repr(char coach_arr[20][MAX_SIZE],int n)
  {
    char str[MAX_SIZE];
    strcpy(str,coach_arr[0]);

    for(int i=1;i<n;i++)
    {
      strcat(str,"-");
      strcat(str,coach_arr[i]);
    }

    return str;

  }

   string seat_repr(int* seat_arr,int n)
  {
    string str=itoa(seat_arr[0]);

    for(int i=1;i<n;i++){
      str=str+"-";
      str=str+itoa(seat_arr[i]);
    }

    return str;

  }


  void writeOutputCSV(const char* filename)
  {
    // Open the file ----------

    ofstream fp;
   // cout << fileExists(filename) << " that it exists ! " << endl;

    if(fileExists(filename))
    {
      int n=0;
      string fname;
     //  cout << "fname : " << fname.c_str() << " exists : " << fileExists(fname) << endl;
      
      while(1)
      {
        char temp[4];
       // cout << "Trying n = " << n << endl;
        fname = string(filename);
        bzero(temp,sizeof(temp));
        sprintf(temp,"_%d",n);
        fname = string(temp) + fname;

        if(!fileExists(fname))
          break;

        n++;

       // cout << "fname : " << fname.c_str() << " exists : " << fileExists(fname) << endl;
      }

      fp.open (fname.c_str(), ios::out | ios::trunc );

    }
    else fp.open (filename, ios::out | ios::trunc );

    if (fp.fail() || fp.bad()) error("Can't create CSV file for writing output ! ");

    for(int i=0; i < req_list_counter ; i++)
    {
      fp << book_detail_list[i]->book_ID << "," << book_detail_list[i]->train_no << "/" << seat_repr(book_detail_list[i]->seat_no,book_detail_list[i]->num_of_berths) << "/" << pos_repr(book_detail_list[i]->position,book_detail_list[i]->num_of_berths)  << "/" << coach_repr(book_detail_list[i]->coaches,book_detail_list[i]->num_of_berths) << "\n";
    }

    fp.close();

  }


public:
  void run()
  {
    parseInputCSV("booking.csv");
    cout<<"done parsing"<<endl;
    // now, the list req_list contains all the records parsed from the CSV file
    dealWithServer(); // send the req_list
    cout<<"done dealing"<<endl;
    writeOutputCSV("tickets.csv");
    cout<<"done writing"<<endl;
  }
  
};

#endif
